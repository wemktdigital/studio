import { config } from 'dotenv';
config();

import '@/ai/flows/smart-suggestion.ts';