
import type { Workspace, User, Channel, DirectMessage, Message } from './types';

// Este arquivo agora contém apenas os tipos necessários
// Todos os dados mock foram removidos e substituídos por dados reais do Supabase
